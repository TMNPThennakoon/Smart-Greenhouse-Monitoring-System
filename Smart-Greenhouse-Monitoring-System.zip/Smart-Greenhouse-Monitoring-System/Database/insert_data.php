<?php
// Database connection
$servername = "localhost";
$username = "root"; // Default MySQL username
$password = "";     // Default MySQL password
$dbname = "smart_green"; // Your database name

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get data from the ESP32 (POST method)
$temperature = $_POST['temperature'];
$humidity = $_POST['humidity'];
$soil_moisture = $_POST['soil_moisture'];
$water_level = $_POST['water_level'];
$pressure = $_POST['pressure'];
$timestamp = date("Y-m-d H:i:s");

// Insert data into the table
$sql = "INSERT INTO sensor_data (timestamp, temperature, humidity, soil_moisture, water_level, pressure) 
        VALUES ('$timestamp', '$temperature', '$humidity', '$soil_moisture', '$water_level', '$pressure')";

if ($conn->query($sql) === TRUE) {
    echo "Data inserted successfully!";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
